import * as THREE from 'three'
import { buildStation } from './station'
import { Simulation } from './sim'
import type { DuckProfile } from './duck'

export type ViewMode = 'grid' | 'single' | 'follow'

export interface CamDef {
  id: string
  label: string
  sub: string
  pos: [number, number, number]
  look: [number, number, number]
  fov?: number
}

export const CAMS: CamDef[] = [
  { id: 'CAM 01', label: '月台 · 西', sub: 'PLATFORM WEST', pos: [-27, 5.5, -4.2], look: [10, 0.5, 0.5], fov: 55 },
  { id: 'CAM 02', label: '月台 · 東', sub: 'PLATFORM EAST', pos: [27, 5.5, -4.2], look: [-10, 0.5, 0.5], fov: 55 },
  { id: 'CAM 03', label: '大堂閘機', sub: 'CONCOURSE GATES', pos: [0, 6.5, -16], look: [0, 0.4, -4], fov: 58 },
  { id: 'CAM 04', label: '出入口', sub: 'EXITS', pos: [14, 4.5, -9], look: [-6, 1, -16.5], fov: 60 },
  { id: 'CAM 05', label: '路軌视角', sub: 'TRACKSIDE', pos: [-24, 0.9, 5.6], look: [12, 1.2, -1], fov: 50 },
  { id: 'CAM 06', label: '全景俯瞰', sub: 'OVERVIEW', pos: [0, 17, 12], look: [0, 0, -6], fov: 50 },
]

export interface SelectedDuck extends DuckProfile {
  stateLabel: string
}

export interface EngineEvents {
  onDuckSelected: (d: SelectedDuck | null) => void
  onTrainStatus: (s: string) => void
  onDuckCount: (n: number) => void
  onFollowEnded: () => void
  onModeChange: (mode: ViewMode, camIndex?: number) => void
}

/* ---------------- procedural sound ---------------- */

class SoundFX {
  private ctx: AudioContext | null = null
  private humGain: GainNode | null = null
  enabled = false

  toggle(): boolean {
    this.enabled = !this.enabled
    if (this.enabled) this.start()
    else this.stop()
    return this.enabled
  }

  private start() {
    if (!this.ctx) {
      this.ctx = new AudioContext()
      // station hum: filtered brown-ish noise
      const len = this.ctx.sampleRate * 2
      const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate)
      const data = buf.getChannelData(0)
      let last = 0
      for (let i = 0; i < len; i++) {
        const white = Math.random() * 2 - 1
        last = (last + 0.02 * white) / 1.02
        data[i] = last * 3.5
      }
      const src = this.ctx.createBufferSource()
      src.buffer = buf
      src.loop = true
      const lp = this.ctx.createBiquadFilter()
      lp.type = 'lowpass'
      lp.frequency.value = 320
      this.humGain = this.ctx.createGain()
      this.humGain.gain.value = 0.05
      src.connect(lp).connect(this.humGain).connect(this.ctx.destination)
      src.start()
    }
    this.ctx.resume()
    if (this.humGain) this.humGain.gain.setTargetAtTime(0.05, this.ctx.currentTime, 0.3)
  }

  private stop() {
    if (this.ctx && this.humGain) {
      this.humGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.2)
    }
  }

  chime() {
    if (!this.enabled || !this.ctx) return
    const t0 = this.ctx.currentTime
    for (const [i, f] of [880, 659.25].entries()) {
      const osc = this.ctx.createOscillator()
      const g = this.ctx.createGain()
      osc.type = 'sine'
      osc.frequency.value = f
      g.gain.setValueAtTime(0, t0 + i * 0.28)
      g.gain.linearRampToValueAtTime(0.08, t0 + i * 0.28 + 0.03)
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + i * 0.28 + 0.5)
      osc.connect(g).connect(this.ctx.destination)
      osc.start(t0 + i * 0.28)
      osc.stop(t0 + i * 0.28 + 0.6)
    }
  }

  rumble(strength: number) {
    if (!this.enabled || !this.ctx || !this.humGain) return
    this.humGain.gain.setTargetAtTime(0.05 + strength * 0.08, this.ctx.currentTime, 0.4)
    this.humGain.gain.setTargetAtTime(0.05, this.ctx.currentTime + 1.2, 0.8)
  }

  dispose() {
    this.ctx?.close()
    this.ctx = null
  }
}

/* ---------------- engine ---------------- */

export class Engine {
  mode: ViewMode = 'grid'
  activeCam = 0
  followId: number | null = null
  sound = new SoundFX()

  private renderer: THREE.WebGLRenderer
  private station = buildStation()
  private sim: Simulation
  private cameras: THREE.PerspectiveCamera[]
  private followCam: THREE.PerspectiveCamera
  private raycaster = new THREE.Raycaster()
  private gridCells: (HTMLElement | null)[] = []
  private cellRects: { x: number; y: number; w: number; h: number }[] = []
  private rectsDirty = true
  private raf = 0
  private lastT = 0
  private clockT = 0
  private resizeObs: ResizeObserver
  private sway = 0
  private canvas: HTMLCanvasElement
  private events: EngineEvents

  constructor(canvas: HTMLCanvasElement, events: EngineEvents) {
    this.canvas = canvas
    this.events = events
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true })
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    this.renderer.setScissorTest(true)

    this.cameras = CAMS.map((c) => {
      const cam = new THREE.PerspectiveCamera(c.fov ?? 55, 1, 0.1, 200)
      cam.position.set(...c.pos)
      cam.lookAt(...c.look)
      return cam
    })
    this.followCam = new THREE.PerspectiveCamera(48, 1, 0.1, 200)

    this.sim = new Simulation(this.station.duckRoot, this.station.train, this.station.screenDoors, {
      onTrainStatus: (s) => this.events.onTrainStatus(s),
      onDuckCount: (n) => this.events.onDuckCount(n),
      onChime: () => this.sound.chime(),
      onRumble: (s) => this.sound.rumble(s),
    })

    this.resizeObs = new ResizeObserver(() => {
      this.rectsDirty = true
      this.resize()
    })
    this.resizeObs.observe(canvas.parentElement ?? canvas)
    this.resize()

    canvas.addEventListener('pointerdown', this.onPointer)
    this.lastT = performance.now()
    this.loop()
  }

  /* ---------------- public API ---------------- */

  setGridCells(cells: (HTMLElement | null)[]) {
    this.gridCells = cells
    this.rectsDirty = true
  }

  setMode(mode: ViewMode) {
    this.mode = mode
    this.rectsDirty = true
    if (mode !== 'follow') this.followId = null
  }

  setActiveCam(i: number) {
    this.activeCam = i
    this.mode = 'single'
    this.followId = null
  }

  followDuck(id: number) {
    this.followId = id
    this.mode = 'follow'
    // snap the follow cam next to the duck immediately (no long lerp from origin)
    const d = this.sim.findDuck(id)
    if (d) {
      const p = d.group.position
      this.followCam.position.set(p.x, 2.2, p.z + 3.2)
      this.followCam.lookAt(p.x, 0.55, p.z)
    }
    this.emitSelected(id)
  }

  unfollow() {
    this.followId = null
    this.mode = 'grid'
    this.events.onDuckSelected(null)
  }

  dispose() {
    cancelAnimationFrame(this.raf)
    this.sim.disposed = true
    this.resizeObs.disconnect()
    this.canvas.removeEventListener('pointerdown', this.onPointer)
    this.sound.dispose()
    this.renderer.dispose()
  }

  /* ---------------- internals ---------------- */

  private emitSelected(id: number | null) {
    if (id === null) {
      this.events.onDuckSelected(null)
      return
    }
    const d = this.sim.findDuck(id)
    if (!d) {
      this.events.onDuckSelected(null)
      return
    }
    this.events.onDuckSelected({ ...d.profile, stateLabel: d.stateLabel() })
  }

  private onPointer = (e: PointerEvent) => {
    const rect = this.canvas.getBoundingClientRect()
    const px = e.clientX - rect.left
    const py = e.clientY - rect.top

    let cam: THREE.PerspectiveCamera
    let nx: number
    let ny: number

    if (this.mode === 'grid') {
      this.updateRects()
      const idx = this.cellRects.findIndex(
        (r) => px >= r.x && px <= r.x + r.w && py >= r.y && py <= r.y + r.h
      )
      if (idx < 0) return
      const r = this.cellRects[idx]
      cam = this.cameras[idx]
      nx = ((px - r.x) / r.w) * 2 - 1
      ny = -((py - r.y) / r.h) * 2 + 1
      const hit = this.pickDuck(cam, nx, ny)
      if (hit !== null) {
        this.followDuck(hit)
        this.events.onModeChange('follow')
      } else {
        this.activeCam = idx
        this.mode = 'single'
        this.events.onDuckSelected(null)
        this.events.onModeChange('single', idx)
      }
      return
    }

    cam = this.mode === 'follow' ? this.followCam : this.cameras[this.activeCam]
    nx = (px / rect.width) * 2 - 1
    ny = -(py / rect.height) * 2 + 1
    const hit = this.pickDuck(cam, nx, ny)
    if (hit !== null) {
      if (this.mode === 'follow') this.followId = hit
      this.emitSelected(hit)
    }
  }

  private pickDuck(cam: THREE.Camera, nx: number, ny: number): number | null {
    this.raycaster.setFromCamera(new THREE.Vector2(nx, ny), cam)
    const hits = this.raycaster.intersectObjects(this.station.duckRoot.children, true)
    for (const h of hits) {
      let o: THREE.Object3D | null = h.object
      while (o) {
        if (typeof o.userData.duckId === 'number') return o.userData.duckId
        o = o.parent
      }
    }
    return null
  }

  private resize() {
    const parent = this.canvas.parentElement
    const w = parent?.clientWidth ?? window.innerWidth
    const h = parent?.clientHeight ?? window.innerHeight
    this.renderer.setSize(w, h, false)
    for (const c of this.cameras) {
      c.aspect = w / h
      c.updateProjectionMatrix()
    }
    this.followCam.aspect = w / h
    this.followCam.updateProjectionMatrix()
  }

  private updateRects() {
    if (!this.rectsDirty) return
    const base = this.canvas.getBoundingClientRect()
    this.cellRects = this.gridCells.map((el) => {
      if (!el) return { x: 0, y: 0, w: 0, h: 0 }
      const r = el.getBoundingClientRect()
      return { x: r.left - base.left, y: r.top - base.top, w: r.width, h: r.height }
    })
    this.rectsDirty = false
  }

  private loop = () => {
    this.raf = requestAnimationFrame(this.loop)
    const now = performance.now()
    const dt = Math.min(0.05, (now - this.lastT) / 1000)
    this.lastT = now
    this.clockT += dt

    this.sim.update(dt, this.clockT)

    // follow target may have left the station
    if (this.mode === 'follow' && this.followId !== null) {
      const d = this.sim.findDuck(this.followId)
      if (!d) {
        this.followId = null
        this.mode = 'grid'
        this.events.onDuckSelected(null)
        this.events.onFollowEnded()
      }
    }

    this.render()
  }

  private render() {
    const cssW = this.renderer.domElement.clientWidth
    const cssH = this.renderer.domElement.clientHeight

    if (this.mode === 'grid') {
      this.updateRects()
      for (let i = 0; i < this.cameras.length; i++) {
        const r = this.cellRects[i]
        if (!r || r.w < 4) continue
        const cam = this.cameras[i]
        cam.aspect = r.w / r.h
        cam.updateProjectionMatrix()
        // subtle CCTV drift
        const def = CAMS[i]
        cam.position.set(
          def.pos[0] + Math.sin(this.clockT * 0.13 + i * 2.1) * 0.35,
          def.pos[1],
          def.pos[2] + Math.cos(this.clockT * 0.1 + i * 1.7) * 0.25
        )
        cam.lookAt(...def.look)
        this.renderer.setViewport(r.x, cssH - r.y - r.h, r.w, r.h)
        this.renderer.setScissor(r.x, cssH - r.y - r.h, r.w, r.h)
        this.renderer.render(this.station.scene, cam)
      }
      return
    }

    let cam: THREE.PerspectiveCamera
    if (this.mode === 'follow' && this.followId !== null) {
      const d = this.sim.findDuck(this.followId)
      cam = this.followCam
      if (d) {
        this.sway += 0.016
        const p = d.group.position
        const angle = d.group.rotation.y + Math.PI + Math.sin(this.sway * 0.21) * 0.5
        const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v))
        const target = new THREE.Vector3(
          clamp(p.x + Math.sin(angle) * 3.0, -30, 30),
          2.1 + Math.sin(this.sway * 0.5) * 0.08,
          clamp(p.z + Math.cos(angle) * 3.0, -15.2, 5)
        )
        cam.position.lerp(target, 0.045)
        const look = new THREE.Vector3(p.x, 0.55, p.z)
        cam.lookAt(look)
      }
    } else {
      cam = this.cameras[this.activeCam]
      const def = CAMS[this.activeCam]
      cam.aspect = cssW / cssH
      cam.updateProjectionMatrix()
      cam.position.set(
        def.pos[0] + Math.sin(this.clockT * 0.13) * 0.4,
        def.pos[1],
        def.pos[2] + Math.cos(this.clockT * 0.1) * 0.3
      )
      cam.lookAt(...def.look)
    }
    this.renderer.setViewport(0, 0, cssW, cssH)
    this.renderer.setScissor(0, 0, cssW, cssH)
    this.renderer.render(this.station.scene, cam)
  }
}
