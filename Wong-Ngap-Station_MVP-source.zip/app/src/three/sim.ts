import * as THREE from 'three'
import { Duck } from './duck'
import { DOOR_XS, GATE_XS, EXIT_XS, TRACK_Z } from './station'

export type TrainPhase = 'away' | 'arriving' | 'dwell' | 'departing'

export interface SimEvents {
  onTrainStatus: (s: string) => void
  onDuckCount: (n: number) => void
  onChime: () => void
  onRumble: (strength: number) => void
}

const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)]
const rand = (a: number, b: number) => a + Math.random() * (b - a)

const TARGET_DUCKS = 24

export class Simulation {
  ducks: Duck[] = []
  trainPhase: TrainPhase = 'away'
  trainX = -90
  private trainTimer = 6 // first train comes quickly
  private dwellTimer = 0
  private spawnTimer = 0
  private doorOpen = 0 // 0 closed .. 1 open
  private lastCount = -1
  private lastStatus = ''
  disposed = false
  private duckRoot: THREE.Group
  private train: THREE.Group
  private screenDoors: { left: THREE.Mesh; right: THREE.Mesh; x: number }[]
  private events: SimEvents

  constructor(
    duckRoot: THREE.Group,
    train: THREE.Group,
    screenDoors: { left: THREE.Mesh; right: THREE.Mesh; x: number }[],
    events: SimEvents
  ) {
    this.duckRoot = duckRoot
    this.train = train
    this.screenDoors = screenDoors
    this.events = events
    // seed initial population on the platform / concourse
    for (let i = 0; i < 16; i++) this.spawnInitial()
  }

  /* ---------------- spawning ---------------- */

  private addDuck(x: number, z: number): Duck {
    const d = new Duck()
    d.group.position.set(x, 0, z)
    this.duckRoot.add(d.group)
    this.ducks.push(d)
    return d
  }

  private spawnInitial() {
    const d = this.addDuck(rand(-28, 28), rand(-15, 1.5))
    if (Math.random() < 0.55 && d.group.position.z > -5) {
      // already on platform -> wait for train
      this.sendToWaitSpot(d)
    } else {
      this.wander(d)
    }
  }

  private spawnEntering() {
    const exitX = pick(EXIT_XS)
    const d = this.addDuck(exitX + rand(-1, 1), -16.2)
    const gate = pick(GATE_XS)
    if (Math.random() < 0.7) {
      // head to platform and wait for the train
      d.setPath(
        [
          [gate + rand(-0.3, 0.3), -7.6],
          [gate + rand(-0.3, 0.3), -4.6],
        ],
        'walk'
      )
      d.boarding = true
    } else {
      // wander the concourse
      d.setPath([[rand(-26, 26), rand(-14, -8)]], 'walk')
    }
  }

  private spawnAlighting() {
    const dx = pick(DOOR_XS)
    const d = this.addDuck(dx + rand(-0.6, 0.6), TRACK_Z - 0.9)
    const gate = pick(GATE_XS)
    const exitX = pick(EXIT_XS)
    d.setPath(
      [
        [dx + rand(-0.5, 0.5), 0.6],
        [gate + rand(-0.3, 0.3), -4.6],
        [gate + rand(-0.3, 0.3), -7.6],
        [exitX + rand(-1, 1), -15.4],
        [exitX, -16.6],
      ],
      'leave'
    )
    d.boarding = false
  }

  /* ---------------- behaviours ---------------- */

  private sendToWaitSpot(d: Duck) {
    const dx = pick(DOOR_XS)
    d.setPath(
      [
        [dx + rand(-1.4, 1.4), rand(0.2, 1.2)],
      ],
      'walk'
    )
    d.boarding = true
  }

  private wander(d: Duck) {
    const onPlatform = d.group.position.z > -5
    if (onPlatform) {
      if (Math.random() < 0.45) {
        this.sendToWaitSpot(d)
        return
      }
      d.setPath([[rand(-28, 28), rand(-4, 1.4)]], 'walk')
    } else {
      if (Math.random() < 0.3) {
        // decide to leave the station
        const exitX = pick(EXIT_XS)
        d.setPath(
          [
            [exitX + rand(-1, 1), -15.4],
            [exitX, -16.6],
          ],
          'leave'
        )
        return
      }
      if (Math.random() < 0.4) {
        // go through gates to platform
        const gate = pick(GATE_XS)
        d.setPath(
          [
            [gate + rand(-0.3, 0.3), -7.6],
            [gate + rand(-0.3, 0.3), -4.6],
            [rand(-24, 24), rand(-3, 1)],
          ],
          'walk'
        )
        d.boarding = Math.random() < 0.6
        return
      }
      d.setPath([[rand(-26, 26), rand(-14, -8)]], 'walk')
    }
  }

  /* ---------------- train cycle ---------------- */

  private setStatus(s: string) {
    if (s !== this.lastStatus) {
      this.lastStatus = s
      this.events.onTrainStatus(s)
    }
  }

  private updateTrain(dt: number) {
    switch (this.trainPhase) {
      case 'away': {
        this.trainTimer -= dt
        this.setStatus(`下一班列車 · ${Math.max(1, Math.ceil(this.trainTimer))}s`)
        if (this.trainTimer <= 0) {
          this.trainPhase = 'arriving'
          this.trainX = -80
          this.events.onChime()
        }
        break
      }
      case 'arriving': {
        this.trainX += dt * 26 * Math.min(1, (Math.abs(this.trainX) / 30) + 0.25)
        this.events.onRumble(0.7)
        this.setStatus('列車正在進站')
        if (this.trainX >= 0) {
          this.trainX = 0
          this.trainPhase = 'dwell'
          this.dwellTimer = 9
          this.events.onChime()
          // release waiting ducks to board (staggered)
          let delay = 0.4
          for (const d of this.ducks) {
            if (d.boarding && (d.state === 'idle' || d.state === 'walk' || d.state === 'wait') && d.group.position.z > -5) {
              const dx = pick(DOOR_XS)
              const captured = d
              setTimeout(() => {
                if (this.disposed || captured.removeMe) return
                captured.setPath(
                  [
                    [dx + rand(-0.4, 0.4), 1.6],
                    [dx + rand(-0.3, 0.3), TRACK_Z - 0.6],
                  ],
                  'board'
                )
              }, delay * 1000)
              delay += rand(0.15, 0.5)
            }
          }
          // alighting passengers
          const n = 2 + Math.floor(Math.random() * 4)
          for (let i = 0; i < n; i++) {
            setTimeout(() => { if (!this.disposed) this.spawnAlighting() }, 500 + i * rand(400, 900))
          }
        }
        break
      }
      case 'dwell': {
        this.dwellTimer -= dt
        this.doorOpen = Math.min(1, this.doorOpen + dt * 2.2)
        this.setStatus('車門開啟 · 請先讓乘客落車')
        if (this.dwellTimer <= 0) {
          this.trainPhase = 'departing'
          this.events.onChime()
        }
        break
      }
      case 'departing': {
        this.doorOpen = Math.max(0, this.doorOpen - dt * 2.5)
        if (this.doorOpen <= 0) {
          this.trainX += dt * (8 + this.trainX * 0.55)
          this.events.onRumble(0.5)
          this.setStatus('列車正在離站')
          if (this.trainX > 85) {
            this.trainPhase = 'away'
            this.trainTimer = rand(14, 22)
            this.trainX = -90
          }
        }
        break
      }
    }
    this.train.position.x = this.trainX
    // slide screen doors
    for (const sd of this.screenDoors) {
      sd.left.position.x = sd.x - 0.55 - this.doorOpen * 0.95
      sd.right.position.x = sd.x + 0.55 + this.doorOpen * 0.95
    }
  }

  /* ---------------- main update ---------------- */

  update(dt: number, t: number) {
    this.updateTrain(dt)

    // spawner keeps the station alive
    this.spawnTimer -= dt
    if (this.spawnTimer <= 0) {
      this.spawnTimer = rand(1.2, 2.6)
      if (this.ducks.length < TARGET_DUCKS) this.spawnEntering()
    }

    for (const d of this.ducks) {
      d.update(dt, t)
      if (d.state === 'idle' && d.idleTimer <= 0 && !d.boarding) {
        this.wander(d)
      } else if (d.state === 'idle' && d.idleTimer <= 0 && d.boarding) {
        // waiting ducks shuffle to a fresh spot occasionally
        if (Math.random() < 0.4) this.sendToWaitSpot(d)
        else d.idleTimer = rand(2, 5)
      }
    }

    // cleanup
    for (let i = this.ducks.length - 1; i >= 0; i--) {
      const d = this.ducks[i]
      if (d.removeMe) {
        this.duckRoot.remove(d.group)
        d.dispose()
        this.ducks.splice(i, 1)
      }
    }

    if (this.ducks.length !== this.lastCount) {
      this.lastCount = this.ducks.length
      this.events.onDuckCount(this.ducks.length)
    }
  }

  findDuck(id: number): Duck | undefined {
    return this.ducks.find((d) => d.id === id)
  }
}
