import * as THREE from 'three'

/* ------------------------------------------------------------------ */
/*  Layout constants (shared with simulation)                          */
/* ------------------------------------------------------------------ */

export const DOOR_XS = [-20, -12, -4, 4, 12, 20] // screen-door / train-door positions
export const GATE_XS = [-15, -9, -3, 3, 9, 15] // turnstile lanes
export const PLATFORM_Z = { min: -5, max: 2.4 }
export const CONCOURSE_Z = { min: -17, max: -7 }
export const EXIT_XS = [-10, 10] // glowing exit doors on north wall
export const TRACK_Z = 4.3

/* ------------------------------------------------------------------ */
/*  Canvas-texture helpers                                             */
/* ------------------------------------------------------------------ */

function textTexture(opts: {
  w: number
  h: number
  bg: string
  draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void
}): THREE.CanvasTexture {
  const c = document.createElement('canvas')
  c.width = opts.w
  c.height = opts.h
  const ctx = c.getContext('2d')!
  ctx.fillStyle = opts.bg
  ctx.fillRect(0, 0, opts.w, opts.h)
  opts.draw(ctx, opts.w, opts.h)
  const tex = new THREE.CanvasTexture(c)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.anisotropy = 4
  return tex
}

const CJK = '"PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Noto Sans CJK TC", sans-serif'

/* ------------------------------------------------------------------ */
/*  Station builder                                                    */
/* ------------------------------------------------------------------ */

export interface StationRefs {
  scene: THREE.Scene
  train: THREE.Group
  trainDoors: THREE.Mesh[]
  screenDoors: { left: THREE.Mesh; right: THREE.Mesh; x: number }[]
  duckRoot: THREE.Group
}

export function buildStation(): StationRefs {
  const scene = new THREE.Scene()
  scene.background = new THREE.Color(0x08080c)
  scene.fog = new THREE.Fog(0x08080c, 55, 140)

  const duckRoot = new THREE.Group()
  scene.add(duckRoot)

  /* lighting -------------------------------------------------------- */
  scene.add(new THREE.HemisphereLight(0x4a5a6e, 0x1c1610, 1.0))
  const key = new THREE.DirectionalLight(0xfff2dd, 0.9)
  key.position.set(10, 20, 8)
  scene.add(key)
  const warm = new THREE.PointLight(0xffd9a0, 30, 40, 1.6)
  warm.position.set(0, 5.5, -1)
  scene.add(warm)
  const cool = new THREE.PointLight(0xa8c8e8, 22, 40, 1.6)
  cool.position.set(0, 5.5, -12)
  scene.add(cool)

  /* materials -------------------------------------------------------- */
  const floorMat = new THREE.MeshStandardMaterial({ color: 0x9a958c, roughness: 0.9 })
  const concourseMat = new THREE.MeshStandardMaterial({ color: 0x8d8a92, roughness: 0.9 })
  const wallMat = new THREE.MeshStandardMaterial({ color: 0xd8d4cc, roughness: 0.95 })
  const pillarMat = new THREE.MeshStandardMaterial({ color: 0xf0b429, roughness: 0.7 })
  const steelMat = new THREE.MeshStandardMaterial({ color: 0xb8bcc4, roughness: 0.35, metalness: 0.7 })
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x1a1a20, roughness: 0.9 })

  /* floors ------------------------------------------------------------ */
  const platform = new THREE.Mesh(new THREE.BoxGeometry(64, 0.4, 7.6), floorMat)
  platform.position.set(0, -0.2, -1.3)
  scene.add(platform)

  const concourse = new THREE.Mesh(new THREE.BoxGeometry(64, 0.4, 10.4), concourseMat)
  concourse.position.set(0, -0.2, -12.2)
  scene.add(concourse)

  // tactile paving strips (MTR yellow guide paths)
  const tactileMat = new THREE.MeshStandardMaterial({ color: 0xe8c832, roughness: 0.85 })
  for (const gx of GATE_XS) {
    const strip = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.02, 10.4), tactileMat)
    strip.position.set(gx, 0.011, -6.1 + 0.0)
    strip.position.z = -6.1
    scene.add(strip)
    const strip2 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.02, 4.6), tactileMat)
    strip2.position.set(gx, 0.011, -0.2)
    scene.add(strip2)
  }

  // platform edge warning line
  const edge = new THREE.Mesh(new THREE.BoxGeometry(64, 0.02, 0.35), tactileMat)
  edge.position.set(0, 0.012, 2.1)
  scene.add(edge)

  /* track bed ---------------------------------------------------------- */
  const bed = new THREE.Mesh(new THREE.BoxGeometry(76, 0.4, 3.6), darkMat)
  bed.position.set(0, -1.5, TRACK_Z)
  scene.add(bed)
  const railMat = new THREE.MeshStandardMaterial({ color: 0x9aa0a8, metalness: 0.9, roughness: 0.3 })
  for (const rz of [TRACK_Z - 0.7, TRACK_Z + 0.7]) {
    const rail = new THREE.Mesh(new THREE.BoxGeometry(76, 0.08, 0.08), railMat)
    rail.position.set(0, -1.26, rz)
    scene.add(rail)
  }
  // sleepers
  const sleeperGeo = new THREE.BoxGeometry(0.24, 0.06, 2)
  const sleeperMesh = new THREE.InstancedMesh(sleeperGeo, darkMat, 38)
  const m4 = new THREE.Matrix4()
  for (let i = 0; i < 38; i++) {
    m4.setPosition(-37 + i * 2, -1.31, TRACK_Z)
    sleeperMesh.setMatrixAt(i, m4)
  }
  scene.add(sleeperMesh)

  /* iconic tiled wall across the tracks (south) ------------------------ */
  const tileTex = textTexture({
    w: 2048,
    h: 512,
    bg: '#e8b80f',
    draw: (ctx, w, h) => {
      // tile grid
      ctx.strokeStyle = 'rgba(120,80,0,0.35)'
      ctx.lineWidth = 2
      for (let x = 0; x <= w; x += 64) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke() }
      for (let y = 0; y <= h; y += 64) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke() }
      // station name calligraphy panels
      ctx.fillStyle = '#f5f2ea'
      ctx.fillRect(w / 2 - 560, 96, 1120, 320)
      ctx.fillStyle = '#1a1a1a'
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.font = `900 210px ${CJK}`
      ctx.fillText('黃 鴨 站', w / 2, 216)
      ctx.font = `700 64px ${CJK}`
      ctx.fillStyle = '#5a5a5a'
      ctx.fillText('W O N G   N G A P', w / 2, 360)
    },
  })
  const nameWall = new THREE.Mesh(
    new THREE.PlaneGeometry(64, 5.4),
    new THREE.MeshStandardMaterial({ map: tileTex, roughness: 0.6 })
  )
  nameWall.position.set(0, 1.4, 6.15)
  nameWall.rotation.y = Math.PI
  scene.add(nameWall)

  // tunnel mouths at both ends of the track wall
  for (const tx of [-30, 30]) {
    const tunnel = new THREE.Mesh(new THREE.BoxGeometry(7, 4.4, 0.4), new THREE.MeshBasicMaterial({ color: 0x000000 }))
    tunnel.position.set(tx, 0.9, 6.05)
    scene.add(tunnel)
  }

  /* platform screen doors ---------------------------------------------- */
  const screenDoors: StationRefs['screenDoors'] = []
  const glassMat = new THREE.MeshStandardMaterial({
    color: 0xbfe8ff, transparent: true, opacity: 0.28, roughness: 0.1, metalness: 0.2,
  })
  const frameMat = new THREE.MeshStandardMaterial({ color: 0xd0d4da, roughness: 0.4, metalness: 0.6 })
  // fixed glass between doors
  for (let i = 0; i <= DOOR_XS.length; i++) {
    const x0 = i === 0 ? -32 : DOOR_XS[i - 1] + 1.1
    const x1 = i === DOOR_XS.length ? 32 : DOOR_XS[i] - 1.1
    const w = x1 - x0
    if (w <= 0.1) continue
    const glass = new THREE.Mesh(new THREE.BoxGeometry(w, 1.7, 0.08), glassMat)
    glass.position.set((x0 + x1) / 2, 0.85, 2.42)
    scene.add(glass)
    const rail = new THREE.Mesh(new THREE.BoxGeometry(w, 0.12, 0.12), frameMat)
    rail.position.set((x0 + x1) / 2, 1.76, 2.42)
    scene.add(rail)
  }
  // sliding door panels
  for (const dx of DOOR_XS) {
    const mk = (side: -1 | 1) => {
      const p = new THREE.Mesh(new THREE.BoxGeometry(1.05, 1.7, 0.07), glassMat.clone())
      p.position.set(dx + side * 0.55, 0.85, 2.42)
      scene.add(p)
      return p
    }
    screenDoors.push({ left: mk(-1), right: mk(1), x: dx })
    const frame = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.14, 0.14), frameMat)
    frame.position.set(dx, 1.78, 2.42)
    scene.add(frame)
  }

  /* pillars + benches + hanging signs on platform ----------------------- */
  for (const px of [-24, -8, 8, 24]) {
    const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.9, 4.4, 0.9), pillarMat)
    pillar.position.set(px, 2.2, -3.6)
    scene.add(pillar)
  }
  const benchMat = new THREE.MeshStandardMaterial({ color: 0x3a6ea5, roughness: 0.6 })
  for (const bx of [-16, 0, 16]) {
    const bench = new THREE.Group()
    const seat = new THREE.Mesh(new THREE.BoxGeometry(3, 0.12, 0.6), benchMat)
    seat.position.y = 0.45
    const leg1 = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.45, 0.5), steelMat)
    leg1.position.set(-1.2, 0.22, 0)
    const leg2 = leg1.clone()
    leg2.position.x = 1.2
    bench.add(seat, leg1, leg2)
    bench.position.set(bx, 0, -2.2)
    scene.add(bench)
  }

  const hangSign = (x: number, z: number, text: string, sub: string) => {
    const tex = textTexture({
      w: 1024, h: 256, bg: '#f5f2ea',
      draw: (ctx, w, h) => {
        ctx.fillStyle = '#1a1a1a'
        ctx.textAlign = 'center'
        ctx.textBaseline = 'middle'
        ctx.font = `900 96px ${CJK}`
        ctx.fillText(text, w / 2, h / 2 - 40)
        ctx.font = `700 52px ${CJK}`
        ctx.fillStyle = '#666'
        ctx.fillText(sub, w / 2, h / 2 + 62)
      },
    })
    const sign = new THREE.Mesh(
      new THREE.BoxGeometry(4.4, 1.1, 0.1),
      new THREE.MeshStandardMaterial({ map: tex, roughness: 0.5 })
    )
    sign.position.set(x, 3.4, z)
    scene.add(sign)
    const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.2, 6), steelMat)
    rod.position.set(x, 4.4, z)
    scene.add(rod)
  }
  hangSign(-14, -0.5, '1 號月台 · 往調景嶺', 'Platform 1 · to Tiu Keng Leng')
  hangSign(14, -0.5, '1 號月台 · 往調景嶺', 'Platform 1 · to Tiu Keng Leng')
  hangSign(0, -11.5, '出 閘 · 大堂', 'Exit Gates · Concourse')

  /* light strips (emissive) ---------------------------------------------- */
  const stripMat = new THREE.MeshBasicMaterial({ color: 0xfff4d6 })
  for (const sx of [-16, 0, 16]) {
    const strip = new THREE.Mesh(new THREE.BoxGeometry(8, 0.08, 0.4), stripMat)
    strip.position.set(sx, 4.6, -1)
    scene.add(strip)
    const strip2 = strip.clone()
    strip2.position.z = -12
    scene.add(strip2)
  }

  /* partition between platform & concourse + turnstiles -------------------- */
  for (let i = 0; i <= GATE_XS.length; i++) {
    const x0 = i === 0 ? -32 : GATE_XS[i - 1] + 0.9
    const x1 = i === GATE_XS.length ? 32 : GATE_XS[i] - 0.9
    const w = x1 - x0
    if (w <= 0.1) continue
    const part = new THREE.Mesh(new THREE.BoxGeometry(w, 1.15, 0.15), wallMat)
    part.position.set((x0 + x1) / 2, 0.575, -6)
    scene.add(part)
  }
  const gateMat = new THREE.MeshStandardMaterial({ color: 0xc8ccd4, roughness: 0.35, metalness: 0.6 })
  const gateLightMat = new THREE.MeshBasicMaterial({ color: 0x35d07f })
  for (const gx of GATE_XS) {
    for (const side of [-0.75, 0.75]) {
      const cab = new THREE.Mesh(new THREE.BoxGeometry(0.35, 1.0, 1.7), gateMat)
      cab.position.set(gx + side, 0.5, -6)
      scene.add(cab)
      const lamp = new THREE.Mesh(new THREE.CircleGeometry(0.06, 10), gateLightMat)
      lamp.position.set(gx + side, 1.01, -6)
      lamp.rotation.x = -Math.PI / 2
      scene.add(lamp)
    }
  }

  /* concourse: ticket machines, ads, north wall with exits ------------------ */
  const northWall = new THREE.Mesh(new THREE.BoxGeometry(64, 5, 0.4), wallMat)
  northWall.position.set(0, 2.5, -17.2)
  scene.add(northWall)

  // glowing exit doors
  const exitTex = textTexture({
    w: 512, h: 192, bg: '#0d5c2e',
    draw: (ctx, w, h) => {
      ctx.fillStyle = '#ffffff'
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.font = `900 96px ${CJK}`
      ctx.fillText('出 EXIT', w / 2, h / 2)
    },
  })
  for (const ex of EXIT_XS) {
    const glow = new THREE.Mesh(
      new THREE.BoxGeometry(3.2, 3.4, 0.2),
      new THREE.MeshBasicMaterial({ color: 0x0a0a12 })
    )
    glow.position.set(ex, 1.7, -16.95)
    scene.add(glow)
    const sign = new THREE.Mesh(
      new THREE.BoxGeometry(2.2, 0.8, 0.12),
      new THREE.MeshBasicMaterial({ map: exitTex })
    )
    sign.position.set(ex, 3.8, -16.9)
    scene.add(sign)
  }

  // ticket machines
  const tmMat = new THREE.MeshStandardMaterial({ color: 0x2a9d8f, roughness: 0.5 })
  for (const tx of [-20, -18.6, 18.6, 20]) {
    const tm = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.7, 0.7), tmMat)
    tm.position.set(tx, 0.85, -15.8)
    scene.add(tm)
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.5), new THREE.MeshBasicMaterial({ color: 0x9adfff }))
    screen.position.set(tx, 1.25, -15.44)
    scene.add(screen)
  }

  // ad lightboxes on north wall
  const adColors = ['#e63946', '#3a6ea5', '#f4a261', '#9b5de5']
  const adTexts = ['鴨記茶餐廳', '黃鴨地產', '嘎嘎銀行', '鴨仔電訊']
  adColors.forEach((col, i) => {
    const tex = textTexture({
      w: 512, h: 384, bg: col,
      draw: (ctx, w, h) => {
        ctx.fillStyle = 'rgba(255,255,255,0.92)'
        ctx.textAlign = 'center'
        ctx.textBaseline = 'middle'
        ctx.font = `900 84px ${CJK}`
        ctx.fillText(adTexts[i], w / 2, h / 2)
      },
    })
    const ad = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 2.4), new THREE.MeshBasicMaterial({ map: tex }))
    ad.position.set(-24 + i * 16, 2.4, -16.98)
    scene.add(ad)
  })

  // side walls (partial, keep diorama open feel)
  for (const sx of [-32.2, 32.2]) {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(0.4, 5, 24), wallMat)
    wall.position.set(sx, 2.5, -5.5)
    scene.add(wall)
  }

  /* the train -------------------------------------------------------------- */
  const train = new THREE.Group()
  const trainBodyMat = new THREE.MeshStandardMaterial({ color: 0xe8e8ec, roughness: 0.35, metalness: 0.4 })
  const trainStripeMat = new THREE.MeshStandardMaterial({ color: 0xd0202e, roughness: 0.5 })
  const trainWinMat = new THREE.MeshStandardMaterial({ color: 0x182430, roughness: 0.15, metalness: 0.3 })

  const body = new THREE.Mesh(new THREE.BoxGeometry(54, 2.5, 2.6), trainBodyMat)
  body.position.y = 1.15
  train.add(body)
  const roof = new THREE.Mesh(new THREE.BoxGeometry(54, 0.3, 2.2), new THREE.MeshStandardMaterial({ color: 0x8a8a90, roughness: 0.6 }))
  roof.position.y = 2.55
  train.add(roof)
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(54.05, 0.35, 2.62), trainStripeMat)
  stripe.position.y = 0.5
  train.add(stripe)
  // window band
  const winBand = new THREE.Mesh(new THREE.BoxGeometry(54.05, 0.8, 2.62), trainWinMat)
  winBand.position.y = 1.65
  train.add(winBand)
  // cab fronts
  for (const side of [-1, 1]) {
    const cab = new THREE.Mesh(new THREE.BoxGeometry(0.6, 2.5, 2.6), trainStripeMat)
    cab.position.set(side * 27.1, 1.15, 0)
    train.add(cab)
    const light = new THREE.Mesh(new THREE.CircleGeometry(0.14, 10), new THREE.MeshBasicMaterial({ color: 0xfff6c8 }))
    light.position.set(side * 27.42, 0.9, 0.6)
    light.rotation.y = side * Math.PI / 2
    train.add(light)
  }
  // train doors (visual panels at DOOR_XS)
  const trainDoors: THREE.Mesh[] = []
  for (const dx of DOOR_XS) {
    const d = new THREE.Mesh(new THREE.BoxGeometry(1.9, 2.1, 0.06), new THREE.MeshStandardMaterial({ color: 0xc0c0c8, roughness: 0.4, metalness: 0.5 }))
    d.position.set(dx, 1.0, -1.32)
    train.add(d)
    trainDoors.push(d)
  }
  train.position.set(-90, -0.55, TRACK_Z)
  scene.add(train)

  return { scene, train, trainDoors, screenDoors, duckRoot }
}
