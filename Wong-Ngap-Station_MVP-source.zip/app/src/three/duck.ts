import * as THREE from 'three'

/* ------------------------------------------------------------------ */
/*  Duck data pools                                                    */
/* ------------------------------------------------------------------ */

export const BODY_COLORS = [
  { hex: 0xffd23f, name: '經典黃' },
  { hex: 0xfff3e0, name: '奶油白' },
  { hex: 0xffc2d4, name: '櫻花粉' },
  { hex: 0xb9e6c9, name: '薄荷綠' },
  { hex: 0xc6dcff, name: '晴空藍' },
  { hex: 0x46464f, name: '限量黑' },
]

export const DUCK_NAMES = [
  '阿黃', '嘎嘎', '豉油', '蛋撻', '菠蘿', '奶茶', '叉燒', '西多',
  '魚蛋', '燒賣', '雞仔', '碗仔', '甘露', '砵仔', '沙嗲', '避風塘',
  '叮叮', '天星', '維港', '雀雀', '肥陳', '阿華', '咖喱', '凍檸',
  '鴛鴦', '糖水', '腸粉', '雲吞', '菠蘿油', '陳皮',
]

export const DUCK_TITLES = [
  '地鐵迷', '攝影師', '返工族', '遊客', '放學學生', '晨運客',
  '夜貓子', '退休雀友', '美食家', '背包客', '趕時間的上班族', '漫遊者',
]

export const DUCK_MOODS = [
  '期待', '有啲睏', '興奮', '趕時間', '放空緊', '肚餓', '心曠神怡', '諗緊嘢',
]

export const DUCK_DESTINATIONS = [
  '金鐘', '旺角', '彩虹', '調景嶺', '尖沙咀', '銅鑼灣', '中環', '觀塘', '黃大仙', '北角',
]

const ACCENT_COLORS = [0xe63946, 0x2a9d8f, 0x3a6ea5, 0xf4a261, 0x9b5de5, 0xef476f, 0x118ab2, 0x6d6875]

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export interface DuckProfile {
  id: number
  name: string
  title: string
  mood: string
  destination: string
  outfit: string[]
  colorName: string
}

export type DuckState = 'walk' | 'idle' | 'wait' | 'board' | 'alight' | 'leave'

const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)]

/* ------------------------------------------------------------------ */
/*  Duck factory + class                                               */
/* ------------------------------------------------------------------ */

let duckSeq = 0

export class Duck {
  id: number
  profile: DuckProfile
  group = new THREE.Group()
  state: DuckState = 'idle'
  speed = 1.1 + Math.random() * 0.5
  path: THREE.Vector3[] = []
  pathIdx = 0
  idleTimer = 0
  removeMe = false
  boarding = false

  private head!: THREE.Group
  private bodyG!: THREE.Group
  private footL!: THREE.Mesh
  private footR!: THREE.Mesh
  private wingL!: THREE.Mesh
  private wingR!: THREE.Mesh
  private suitcase?: THREE.Group
  private phase = Math.random() * Math.PI * 2
  private seed = Math.random() * 100
  private blob!: THREE.Mesh

  constructor() {
    this.id = duckSeq++
    const body = pick(BODY_COLORS)
    const outfit: string[] = []

    const bodyMat = new THREE.MeshStandardMaterial({ color: body.hex, flatShading: true, roughness: 0.9 })
    const beakMat = new THREE.MeshStandardMaterial({ color: 0xff8c1a, flatShading: true, roughness: 0.8 })
    const eyeMat = new THREE.MeshStandardMaterial({ color: 0x14141a, roughness: 0.4 })
    const accent = new THREE.MeshStandardMaterial({ color: pick(ACCENT_COLORS), flatShading: true, roughness: 0.85 })

    /* body */
    this.bodyG = new THREE.Group()
    const torso = new THREE.Mesh(new THREE.SphereGeometry(0.3, 10, 8), bodyMat)
    torso.scale.set(1, 0.88, 1.25)
    torso.position.y = 0.34
    this.bodyG.add(torso)

    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.22, 6), bodyMat)
    tail.rotation.x = -Math.PI / 2.4
    tail.position.set(0, 0.42, -0.36)
    this.bodyG.add(tail)

    /* wings */
    const wingGeo = new THREE.SphereGeometry(0.16, 8, 6)
    this.wingL = new THREE.Mesh(wingGeo, bodyMat)
    this.wingL.scale.set(0.45, 0.8, 1.1)
    this.wingL.position.set(-0.28, 0.36, 0)
    this.wingR = this.wingL.clone()
    this.wingR.position.x = 0.28
    this.bodyG.add(this.wingL, this.wingR)

    /* head */
    this.head = new THREE.Group()
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 8), bodyMat)
    this.head.add(skull)
    const beak = new THREE.Mesh(new THREE.ConeGeometry(0.085, 0.2, 6), beakMat)
    beak.rotation.x = Math.PI / 2
    beak.scale.set(1.4, 1, 0.55)
    beak.position.set(0, -0.02, 0.24)
    this.head.add(beak)
    const eyeGeo = new THREE.SphereGeometry(0.032, 6, 6)
    const eyeL = new THREE.Mesh(eyeGeo, eyeMat)
    eyeL.position.set(-0.09, 0.05, 0.15)
    const eyeR = eyeL.clone()
    eyeR.position.x = 0.09
    this.head.add(eyeL, eyeR)
    this.head.position.set(0, 0.62, 0.22)
    this.bodyG.add(this.head)

    /* feet */
    const footGeo = new THREE.BoxGeometry(0.09, 0.04, 0.16)
    this.footL = new THREE.Mesh(footGeo, beakMat)
    this.footL.position.set(-0.11, 0.02, 0.02)
    this.footR = this.footL.clone()
    this.footR.position.x = 0.11
    this.bodyG.add(this.footL, this.footR)

    this.group.add(this.bodyG)

    /* blob shadow */
    const blobTex = Duck.blobTexture()
    this.blob = new THREE.Mesh(
      new THREE.PlaneGeometry(0.7, 0.7),
      new THREE.MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, opacity: 0.55 })
    )
    this.blob.rotation.x = -Math.PI / 2
    this.blob.position.y = 0.015
    this.group.add(this.blob)

    /* accessories ------------------------------------------------ */
    const roll = () => Math.random()

    if (roll() < 0.34) {
      // bucket hat
      const hat = new THREE.Group()
      const top = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.15, 0.12, 10), accent)
      top.position.y = 0.05
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.26, 0.03, 10), accent)
      hat.add(top, brim)
      hat.position.y = 0.17
      hat.rotation.z = (Math.random() - 0.5) * 0.2
      this.head.add(hat)
      outfit.push('漁夫帽')
    } else if (roll() < 0.3) {
      // cap
      const cap = new THREE.Group()
      const dome = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6, 0, Math.PI * 2, 0, Math.PI / 2), accent)
      const peak = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.02, 0.14), accent)
      peak.position.set(0, 0.02, 0.18)
      cap.add(dome, peak)
      cap.position.y = 0.13
      this.head.add(cap)
      outfit.push('鴨舌帽')
    }

    if (roll() < 0.28) {
      // headphones
      const hp = new THREE.Group()
      const band = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.025, 6, 12, Math.PI), accent)
      band.rotation.z = 0
      const cupGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.04, 8)
      const cupL = new THREE.Mesh(cupGeo, accent)
      cupL.rotation.z = Math.PI / 2
      cupL.position.set(-0.18, -0.02, 0)
      const cupR = cupL.clone()
      cupR.position.x = 0.18
      hp.add(band, cupL, cupR)
      hp.position.y = 0.08
      this.head.add(hp)
      outfit.push('耳機')
    }

    if (roll() < 0.22) {
      // sunglasses
      const sg = new THREE.Mesh(
        new THREE.BoxGeometry(0.26, 0.06, 0.05),
        new THREE.MeshStandardMaterial({ color: 0x16161c, roughness: 0.3 })
      )
      sg.position.set(0, 0.05, 0.17)
      this.head.add(sg)
      outfit.push('太陽眼鏡')
    }

    if (roll() < 0.26) {
      // bowtie
      const bow = new THREE.Group()
      const wGeo = new THREE.ConeGeometry(0.05, 0.1, 4)
      const wl = new THREE.Mesh(wGeo, accent)
      wl.rotation.z = Math.PI / 2
      wl.position.x = -0.055
      const wr = new THREE.Mesh(wGeo, accent)
      wr.rotation.z = -Math.PI / 2
      wr.position.x = 0.055
      const knot = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 6), accent)
      bow.add(wl, wr, knot)
      bow.position.set(0, 0.48, 0.3)
      this.bodyG.add(bow)
      outfit.push('煲呔')
    }

    if (roll() < 0.3) {
      // backpack
      const bp = new THREE.Group()
      const pack = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.3, 0.14), accent)
      const pocket = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.14, 0.05), accent)
      pocket.position.set(0, -0.04, -0.09)
      bp.add(pack, pocket)
      bp.position.set(0, 0.42, -0.33)
      this.bodyG.add(bp)
      outfit.push('背囊')
    }

    if (roll() < 0.24) {
      // camera on chest
      const cam = new THREE.Group()
      const bodyC = new THREE.Mesh(
        new THREE.BoxGeometry(0.16, 0.11, 0.07),
        new THREE.MeshStandardMaterial({ color: 0x2b2b33, roughness: 0.5 })
      )
      const lens = new THREE.Mesh(
        new THREE.CylinderGeometry(0.04, 0.045, 0.06, 10),
        new THREE.MeshStandardMaterial({ color: 0x101014, roughness: 0.2 })
      )
      lens.rotation.x = Math.PI / 2
      lens.position.z = 0.06
      cam.add(bodyC, lens)
      cam.position.set(0, 0.42, 0.33)
      this.bodyG.add(cam)
      outfit.push('相機')
    }

    if (roll() < 0.22) {
      // scarf
      const scarf = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.05, 6, 12), accent)
      scarf.rotation.x = Math.PI / 2
      scarf.position.set(0, 0.52, 0.16)
      this.bodyG.add(scarf)
      outfit.push('頸巾')
    }

    if (roll() < 0.26) {
      // suitcase dragged behind
      const sc = new THREE.Group()
      const box = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.34, 0.14), accent)
      box.position.y = 0.19
      const handle = new THREE.Mesh(
        new THREE.CylinderGeometry(0.012, 0.012, 0.3, 6),
        new THREE.MeshStandardMaterial({ color: 0x888890, roughness: 0.4 })
      )
      handle.rotation.x = 0.5
      handle.position.set(0, 0.42, 0.08)
      const wheelGeo = new THREE.SphereGeometry(0.03, 6, 6)
      const w1 = new THREE.Mesh(wheelGeo, eyeMat)
      w1.position.set(-0.08, 0.03, 0)
      const w2 = w1.clone()
      w2.position.x = 0.08
      sc.add(box, handle, w1, w2)
      sc.position.set(0, 0, -0.52)
      this.suitcase = sc
      this.group.add(sc)
      outfit.push('篋')
    }

    if (outfit.length === 0) outfit.push('素顏出街')

    this.profile = {
      id: this.id,
      name: pick(DUCK_NAMES),
      title: pick(DUCK_TITLES),
      mood: pick(DUCK_MOODS),
      destination: pick(DUCK_DESTINATIONS),
      outfit,
      colorName: body.name,
    }

    // register for raycasting
    this.group.traverse((o) => {
      o.userData.duckId = this.id
    })
  }

  private static _blobTex: THREE.CanvasTexture | null = null
  private static blobTexture(): THREE.CanvasTexture {
    if (this._blobTex) return this._blobTex
    const c = document.createElement('canvas')
    c.width = c.height = 64
    const ctx = c.getContext('2d')!
    const g = ctx.createRadialGradient(32, 32, 4, 32, 32, 30)
    g.addColorStop(0, 'rgba(0,0,0,0.55)')
    g.addColorStop(1, 'rgba(0,0,0,0)')
    ctx.fillStyle = g
    ctx.fillRect(0, 0, 64, 64)
    this._blobTex = new THREE.CanvasTexture(c)
    return this._blobTex
  }

  setPath(points: Array<[number, number]>, state: DuckState = 'walk') {
    this.path = points.map(([x, z]) => new THREE.Vector3(x, 0, z))
    this.pathIdx = 0
    this.state = state
  }

  get position(): THREE.Vector3 {
    return this.group.position
  }

  update(dt: number, t: number) {
    const g = this.group

    if (this.state === 'walk' || this.state === 'board' || this.state === 'alight' || this.state === 'leave') {
      if (this.pathIdx >= this.path.length) {
        this.onPathDone()
      } else {
        const target = this.path[this.pathIdx]
        const dx = target.x - g.position.x
        const dz = target.z - g.position.z
        const dist = Math.hypot(dx, dz)
        const step = this.speed * dt
        if (dist < Math.max(step, 0.06)) {
          this.pathIdx++
        } else {
          const nx = dx / dist
          const nz = dz / dist
          g.position.x += nx * step
          g.position.z += nz * step
          const targetRot = Math.atan2(nx, nz)
          let dr = targetRot - g.rotation.y
          while (dr > Math.PI) dr -= Math.PI * 2
          while (dr < -Math.PI) dr += Math.PI * 2
          g.rotation.y += dr * Math.min(1, dt * 8)
        }
        // waddle
        this.phase += dt * this.speed * 9
        this.bodyG.rotation.z = Math.sin(this.phase) * 0.11
        this.bodyG.position.y = Math.abs(Math.sin(this.phase)) * 0.045
        this.footL.position.z = 0.02 + Math.sin(this.phase) * 0.07
        this.footR.position.z = 0.02 - Math.sin(this.phase) * 0.07
        this.wingL.rotation.z = Math.sin(this.phase) * 0.15
        this.wingR.rotation.z = -Math.sin(this.phase) * 0.15
        this.head.rotation.y = Math.sin(t * 0.9 + this.seed) * 0.25
        if (this.suitcase) {
          this.suitcase.position.y = Math.abs(Math.sin(this.phase + 1)) * 0.02
          this.suitcase.rotation.x = Math.sin(this.phase) * 0.05
        }
      }
    } else {
      // idle / wait: look around, breathe
      this.bodyG.rotation.z *= 0.9
      this.bodyG.position.y = Math.sin(t * 2 + this.seed) * 0.012
      this.head.rotation.y = Math.sin(t * 0.55 + this.seed) * 0.65
      this.head.rotation.x = Math.sin(t * 0.8 + this.seed * 2) * 0.1
      if (this.state === 'idle') {
        this.idleTimer -= dt
      }
    }
  }

  private onPathDone() {
    if (this.state === 'board') {
      this.removeMe = true // boarded the train
    } else if (this.state === 'leave') {
      this.removeMe = true // left the station
    } else if (this.state === 'alight') {
      this.state = 'idle'
      this.idleTimer = 1 + Math.random() * 2
    } else {
      this.state = 'idle'
      this.idleTimer = 2 + Math.random() * 6
    }
  }

  stateLabel(): string {
    switch (this.state) {
      case 'walk': return '行緊'
      case 'wait': return '等車中'
      case 'board': return '上車中'
      case 'alight': return '出閘中'
      case 'leave': return '離站中'
      default: return '放空緊'
    }
  }

  dispose() {
    this.group.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        o.geometry.dispose()
        const m = o.material
        if (Array.isArray(m)) m.forEach((x) => x.dispose())
        else m.dispose()
      }
    })
  }
}
