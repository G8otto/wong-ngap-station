import { useEffect, useRef, useState, useCallback } from 'react'
import { Engine, CAMS, type SelectedDuck, type ViewMode } from '@/three/engine'

const MONO = 'ui-monospace, "SF Mono", "Cascadia Code", Menlo, Consolas, "PingFang SC", "Microsoft YaHei", monospace'

function useHKClock() {
  const [now, setNow] = useState('')
  useEffect(() => {
    const tick = () =>
      setNow(
        new Date().toLocaleString('en-HK', {
          timeZone: 'Asia/Hong_Kong',
          hour12: false,
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      )
    tick()
    const id = setInterval(tick, 1000)
    return () => clearInterval(id)
  }, [])
  return now
}

function RecDot() {
  return <span className="rec-dot" aria-hidden />
}

export default function Observatory() {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const cellRefs = useRef<(HTMLDivElement | null)[]>([])
  const engineRef = useRef<Engine | null>(null)

  const [mode, setMode] = useState<ViewMode>('grid')
  const [activeCam, setActiveCam] = useState(0)
  const [selected, setSelected] = useState<SelectedDuck | null>(null)
  const [trainStatus, setTrainStatus] = useState('系統啟動中')
  const [duckCount, setDuckCount] = useState(0)
  const [soundOn, setSoundOn] = useState(false)
  const [glitchIdx, setGlitchIdx] = useState(-1)
  const clock = useHKClock()

  useEffect(() => {
    if (!canvasRef.current) return
    const engine = new Engine(canvasRef.current, {
      onDuckSelected: (d) => {
        setSelected(d)
        if (d && engine.mode === 'follow') setMode('follow')
      },
      onTrainStatus: setTrainStatus,
      onDuckCount: setDuckCount,
      onFollowEnded: () => setMode('grid'),
      onModeChange: (m, cam) => {
        setMode(m)
        if (typeof cam === 'number') setActiveCam(cam)
      },
    })
    engine.setGridCells(cellRefs.current)
    engineRef.current = engine
    // debug / capture hook for scripted screenshots
    ;(window as unknown as { __engine?: Engine }).__engine = engine
    return () => {
      engine.dispose()
      engineRef.current = null
    }
  }, [])

  // random signal glitch on a feed frame
  useEffect(() => {
    if (mode !== 'grid') return
    const id = setInterval(() => {
      const idx = Math.floor(Math.random() * CAMS.length)
      setGlitchIdx(idx)
      setTimeout(() => setGlitchIdx(-1), 220)
    }, 4200)
    return () => clearInterval(id)
  }, [mode])

  const backToGrid = useCallback(() => {
    engineRef.current?.setMode('grid')
    engineRef.current?.unfollow()
    setMode('grid')
    setSelected(null)
  }, [])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') backToGrid()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [backToGrid])

  const switchCam = (i: number) => {
    const next = (i + CAMS.length) % CAMS.length
    engineRef.current?.setActiveCam(next)
    setActiveCam(next)
    setMode('single')
    setSelected(null)
  }

  const followSelected = () => {
    if (selected && engineRef.current) {
      engineRef.current.followDuck(selected.id)
      setMode('follow')
    }
  }

  const toggleSound = () => {
    const eng = engineRef.current
    if (eng) setSoundOn(eng.sound.toggle())
  }

  return (
    <div ref={containerRef} className="fixed inset-0 overflow-hidden bg-[#08080c] select-none">
      {/* 3D canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full cursor-crosshair" />

      {/* scanlines + vignette over everything */}
      <div className="scanlines pointer-events-none absolute inset-0 z-10" />
      <div className="vignette pointer-events-none absolute inset-0 z-10" />

      {/* header */}
      <header
        className="absolute inset-x-0 top-0 z-20 flex h-12 items-center gap-4 border-b px-4"
        style={{
          background: 'rgba(30,30,36,0.92)',
          borderColor: 'rgba(74,74,90,0.6)',
          backdropFilter: 'blur(8px)',
          fontFamily: MONO,
        }}
      >
        <div className="flex items-center gap-2.5">
          <span className="inline-block h-2.5 w-2.5 rounded-full bg-[#f0b429]" />
          <span className="text-[13px] font-bold tracking-[0.18em] text-[#e0e0e0]">
            黃鴨站觀測系統
          </span>
          <span className="hidden text-[11px] tracking-[0.14em] text-[#9a9aab] sm:inline">
            WONG NGAP STATION OBSERVATORY
          </span>
        </div>

        <div className="ml-auto flex items-center gap-3 text-[11px] text-[#9a9aab]">
          <span className="hidden items-center gap-1.5 md:flex">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-[#35d07f]" />
            在站鴨數 {String(duckCount).padStart(2, '0')}
          </span>
          <span className="hidden items-center gap-1.5 rounded border border-[#4a4a5a] px-2 py-1 text-[#00aaff] lg:flex">
            {trainStatus}
          </span>
          <span className="tabular-nums text-[#e0e0e0]">{clock} HKT</span>
          <button
            onClick={toggleSound}
            className="flex items-center gap-1.5 rounded border border-[#4a4a5a] px-2 py-1 text-[#9a9aab] transition-colors duration-200 hover:border-[#00aaff] hover:text-[#00aaff]"
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M11 5 6 9H2v6h4l5 4V5z" />
              {soundOn && <path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13" />}
              {!soundOn && <path d="m22 9-6 6M16 9l6 6" />}
            </svg>
            {soundOn ? '聲音開' : '聲音關'}
          </button>
        </div>
      </header>

      {/* grid-mode feed frames */}
      {mode === 'grid' && (
        <div className="pointer-events-none absolute inset-0 z-10 grid grid-cols-2 grid-rows-3 gap-2 px-3 pb-12 pt-14 md:grid-cols-3 md:grid-rows-2">
          {CAMS.map((cam, i) => (
            <div
              key={cam.id}
              ref={(el) => {
                cellRefs.current[i] = el
              }}
              className={`feed-frame pointer-events-none relative ${glitchIdx === i ? 'feed-glitch' : ''}`}
            >
              <div className="absolute left-2 top-2 flex items-center gap-2" style={{ fontFamily: MONO }}>
                <RecDot />
                <span className="text-[10px] font-bold tracking-[0.15em] text-[#e0e0e0] text-shadow">
                  {cam.id} · {cam.label}
                </span>
                <span className="hidden text-[9px] tracking-[0.12em] text-[#9a9aab] text-shadow sm:inline">
                  {cam.sub}
                </span>
              </div>
              <div
                className="absolute bottom-2 right-2 text-[9px] tracking-[0.12em] text-[#9a9aab] text-shadow"
                style={{ fontFamily: MONO }}
              >
                LIVE
              </div>
            </div>
          ))}
        </div>
      )}

      {/* single / follow mode chrome */}
      {mode !== 'grid' && (
        <div className="pointer-events-none absolute inset-0 z-10">
          <div
            className="absolute left-4 top-16 flex items-center gap-2.5"
            style={{ fontFamily: MONO }}
          >
            <RecDot />
            <span className="text-[12px] font-bold tracking-[0.18em] text-[#e0e0e0] text-shadow">
              {mode === 'follow' && selected
                ? `FOLLOW · ${selected.name}`
                : `${CAMS[activeCam].id} · ${CAMS[activeCam].label}`}
            </span>
            <span className="text-[10px] tracking-[0.14em] text-[#9a9aab] text-shadow">
              {mode === 'follow' ? 'TRACKING SUBJECT' : CAMS[activeCam].sub}
            </span>
          </div>
          <div className="pointer-events-auto absolute right-4 top-16 flex items-center gap-2">
            {mode === 'single' && (
              <>
                <button
                  onClick={() => switchCam(activeCam - 1)}
                  className="rounded border border-[#4a4a5a] px-2.5 py-1.5 text-[11px] text-[#9a9aab] transition-colors duration-200 hover:border-[#00aaff] hover:text-[#00aaff]"
                  style={{ background: 'rgba(30,30,36,0.85)', backdropFilter: 'blur(8px)', fontFamily: MONO }}
                >
                  ◀ 上一機位
                </button>
                <button
                  onClick={() => switchCam(activeCam + 1)}
                  className="rounded border border-[#4a4a5a] px-2.5 py-1.5 text-[11px] text-[#9a9aab] transition-colors duration-200 hover:border-[#00aaff] hover:text-[#00aaff]"
                  style={{ background: 'rgba(30,30,36,0.85)', backdropFilter: 'blur(8px)', fontFamily: MONO }}
                >
                  下一機位 ▶
                </button>
              </>
            )}
            <button
              onClick={backToGrid}
              className="rounded border border-[#4a4a5a] px-3 py-1.5 text-[11px] tracking-[0.14em] text-[#9a9aab] transition-colors duration-200 hover:border-[#00aaff] hover:text-[#00aaff]"
              style={{ background: 'rgba(30,30,36,0.85)', backdropFilter: 'blur(8px)', fontFamily: MONO }}
            >
              返回監控牆 ESC
            </button>
          </div>
        </div>
      )}

      {/* duck profile card */}
      {selected && (
        <aside
          className="absolute bottom-12 right-4 z-20 w-64 rounded-md border p-4"
          style={{
            background: 'rgba(30,30,36,0.94)',
            borderColor: 'rgba(74,74,90,0.7)',
            backdropFilter: 'blur(8px)',
            boxShadow: '0 6px 24px rgba(0,0,0,0.5)',
            fontFamily: MONO,
          }}
        >
          <div className="mb-3 flex items-start justify-between">
            <div>
              <div className="text-[16px] font-bold tracking-[0.1em] text-[#e0e0e0]">
                {selected.name}
              </div>
              <div className="text-[10px] tracking-[0.14em] text-[#00aaff]">
                SUBJECT #{String(selected.id).padStart(3, '0')} · {selected.stateLabel}
              </div>
            </div>
            <button
              onClick={() => setSelected(null)}
              className="text-[#9a9aab] transition-colors hover:text-[#e0e0e0]"
              aria-label="關閉"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M18 6 6 18M6 6l12 12" />
              </svg>
            </button>
          </div>

          <dl className="space-y-1.5 text-[11px]">
            <div className="flex justify-between">
              <dt className="text-[#9a9aab]">身份</dt>
              <dd className="text-[#e0e0e0]">{selected.title}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#9a9aab]">毛色</dt>
              <dd className="text-[#e0e0e0]">{selected.colorName}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#9a9aab]">心情</dt>
              <dd className="text-[#e0e0e0]">{selected.mood}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#9a9aab]">目的地</dt>
              <dd className="text-[#e0e0e0]">{selected.destination}</dd>
            </div>
          </dl>

          <div className="mt-3 border-t border-[#4a4a5a]/50 pt-2.5">
            <div className="mb-1.5 text-[10px] tracking-[0.14em] text-[#9a9aab]">裝扮</div>
            <div className="flex flex-wrap gap-1.5">
              {selected.outfit.map((o) => (
                <span
                  key={o}
                  className="rounded-sm border border-[#4a4a5a] px-1.5 py-0.5 text-[10px] text-[#e0e0e0]"
                >
                  {o}
                </span>
              ))}
            </div>
          </div>

          {mode !== 'follow' && (
            <button
              onClick={followSelected}
              className="mt-3.5 w-full rounded-sm border border-[#00aaff]/60 py-1.5 text-[11px] font-bold tracking-[0.18em] text-[#00aaff] transition-colors duration-200 hover:bg-[#00aaff]/10"
            >
              跟蹤此鴨 →
            </button>
          )}
        </aside>
      )}

      {/* bottom hint bar */}
      <footer
        className="absolute inset-x-0 bottom-0 z-20 flex h-9 items-center justify-between border-t px-4 text-[10px] tracking-[0.14em] text-[#9a9aab]"
        style={{
          background: 'rgba(30,30,36,0.92)',
          borderColor: 'rgba(74,74,90,0.6)',
          backdropFilter: 'blur(8px)',
          fontFamily: MONO,
        }}
      >
        <span>
          {mode === 'grid'
            ? '點擊畫面放大機位 · 點擊鴨子開始跟蹤'
            : mode === 'single'
              ? '點擊鴨子查看檔案'
              : '跟蹤中 · 點擊其他鴨子切換目標'}
        </span>
        <span className="hidden sm:inline">MVP BUILD 0.1 · 港鐵黃鴨站</span>
      </footer>
    </div>
  )
}
